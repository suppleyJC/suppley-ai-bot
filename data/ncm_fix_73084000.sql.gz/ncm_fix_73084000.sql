SET NAMES utf8mb4;
SET autocommit=0;
INSERT INTO ncm_tax_rates (ncmCode,description,iiRate,ipiRate,pisRate,cofinsRate,mercosulIiRate,notes) VALUES
('73084000','73 Obras de ferro fundido, ferro ou aço. > 73.08 Construções e suas partes (por exemplo, pontes e elementos de pontes, comportas, torres, pórticos, pilares, colunas, armações, estruturas para telhados, portas e janelas, e seus caixilhos, alizares e soleiras, portas de correr, balaustradas), de ferro fundido, ferro ou aço, exceto as construções pré-fabricadas da posição 94.06; chapas, barras, perfis, tubos e semelhantes, de ferro fundido, ferro ou aço, próprios para construções. > 7308.40.00 - Material para andaimes, para cofragens ou para escoramentos',2500,0,210,1025,0,'II 25% DCC vigente ate 2026-06-23 (Res.GECEX 740/elevacao) | MDIC 2026-06-19')
ON DUPLICATE KEY UPDATE iiRate=VALUES(iiRate),notes=VALUES(notes);
COMMIT;
